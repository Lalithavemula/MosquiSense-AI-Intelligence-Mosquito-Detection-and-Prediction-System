﻿document.addEventListener('DOMContentLoaded', () => {
  const locationDisplay = document.getElementById('location');
  const complaintForm = document.getElementById('complaintForm');
  const reportsList = document.getElementById('reportsList');

  // 🌍 Get live location with village, street, and pincode
  if (navigator.geolocation && locationDisplay) {
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${latitude}&lon=${longitude}`)
          .then(res => res.json())
          .then(data => {
            const address = data.display_name || 'Unknown location';
            locationDisplay.textContent = `📍 ${address}`;
          });
      },
      () => locationDisplay.textContent = '⚠️ Location access denied.'
    );
  }

  // 📝 Handle complaint submission
  if (complaintForm) {
    complaintForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const title = document.getElementById('problem').value.trim();
      const desc = document.getElementById('description').value.trim();
      const file = document.getElementById('fileUpload').files[0];
      const loc = locationDisplay.textContent;

      const reportHTML = `
        <div class="report glass">
          <h4>${title}</h4>
          <p>${desc}</p>
          <small>${loc}</small>
          ${file ? `<p>📸 ${file.name}</p>` : ''}
        </div>
      `;
      reportsList.innerHTML = reportHTML + reportsList.innerHTML;
      complaintForm.reset();
      alert("Complaint submitted successfully!");
    });
  }
});
const uploadInput = document.getElementById("imageUpload");
const resultBox = document.getElementById("result");

document.getElementById("predictBtn").addEventListener("click", async () => {
  const file = uploadInput.files[0];
  if (!file) {
    alert("Please select an image first!");
    return;
  }

  const formData = new FormData();
  formData.append("file", file);

  try {
    const response = await fetch("http://127.0.0.1:5000/predict", {
      method: "POST",
      body: formData,
    });

    const data = await response.json();
    resultBox.innerHTML = `
      <h3>Prediction: ${data.predicted_class}</h3>
      <p>Risk Level: <strong>${data.risk_level}</strong></p>
    `;
  } catch (err) {
    console.error(err);
    alert("Error connecting to backend!");
  }
});


function logout() {
  window.location.href = "index.html";
}
