﻿document.addEventListener('DOMContentLoaded', () => {
    // ----- LOGIN FORM -----
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();

            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value.trim();
            const role = document.getElementById('roleSelect').value;

            if (!email || !password || !role) {
                alert("Please fill all fields!");
                return;
            }

            // Store role and email in sessionStorage
            sessionStorage.setItem('role', role);
            sessionStorage.setItem('email', email);

            // Redirect based on role
            if (role === 'admin') {
                window.location.href = 'admin_dashboard.html';
            } else {
                window.location.href = 'dashboard.html';
            }
        });
    }

    // ----- SIGNUP FORM -----
    const signupForm = document.getElementById('signupForm');
    if (signupForm) {
        signupForm.addEventListener('submit', (e) => {
            e.preventDefault();

            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value.trim();
            const type = document.getElementById('type').value;

            if (!name || !email || !password || !type) {
                alert("Please fill all fields!");
                return;
            }

            // Save signup info temporarily (you can replace with backend later)
            sessionStorage.setItem('signupName', name);
            sessionStorage.setItem('signupEmail', email);
            sessionStorage.setItem('signupType', type);

            alert(`Sign up successful as ${type}! Please login.`);
            // Redirect to login page
            window.location.href = 'index.html';
        });
    }
});
